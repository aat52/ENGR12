%Team R13

clear 
clc

a='';
b='';
c='';
d='';
e='';
%load data
load MatData.txt

%get matrixa and arrayb
matrix_dim=size(MatData);
numrows=matrix_dim(1);
numcols=matrix_dim(2);

matrixa=MatData(:,1:numrows);
arrayb=MatData(:,numcols);

x=inv(matrixa)*arrayb;

%display answer
disp('The answer to the system is:')
disp(x)