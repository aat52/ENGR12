%calculate A function
function [A]=calculate_A(P,n,i)

A=P*((i*(1+i)^(n))/((1+i)^(n)-1));
