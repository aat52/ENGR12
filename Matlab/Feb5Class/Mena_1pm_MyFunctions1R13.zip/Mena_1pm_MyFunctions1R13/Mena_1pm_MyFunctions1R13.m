%Team R13
%display purpose
clear
clc


disp('The purpose of this program is to compute and display the monthly loan payments')

[P,n,i]=user_inputs;

A=calculate_A(P,n,i);

disp('Your monthly payment amount is: ')
disp(A)