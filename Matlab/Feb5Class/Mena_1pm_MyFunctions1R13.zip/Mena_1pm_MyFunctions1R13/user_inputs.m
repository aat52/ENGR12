%function user_inputs
function [P,n,i]=user_inputs
   
P=input('What is the amount borrowed?');
n=input('What is the number of months to pay back the loan?');
interest=input('What is the monthly interest rate in percentage?');
i=interest/100;